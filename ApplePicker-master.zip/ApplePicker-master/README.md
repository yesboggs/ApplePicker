# ApplePicker
Gibson Ch 28 - Apple Picker Prototype

The first several steps have been completed for you. The objects exist, the materials have been set, and the camera has been set to orthographic.
